---
name: global-policy-tracker
agent_created: true
description: Build and run a global skilled immigration policy tracker. Use this skill when the user wants to monitor immigration policy changes across OECD destinations, create a CV-worthy open-source project, or automate policy intelligence for New Zealand, Germany, Netherlands, Sweden, Finland, Australia, Canada, Ireland, UK, and Singapore.
---

# Global Policy Tracker Skill

## Purpose

Help the user build a reusable, CV-worthy system that tracks skilled immigration policy changes across multiple developed countries. The skill combines web scraping, change detection, versioned data storage, and automated reporting.

## When to Use This Skill

- The user asks to track immigration policy changes in more than one country.
- The user wants to turn policy research into a publishable or CV-worthy project.
- The user needs a new run of the existing `global_policy_tracker.py` script or wants to extend it.
- The user wants a comparison of salary thresholds, age limits, or visa pathways across destinations.

## Core Workflow

1. **Set up the project**
   - Create a dedicated project folder.
   - Place `global_policy_tracker.py` in the root.
   - Ensure dependencies are installed: `requests`, `beautifulsoup4`, `lxml`, `pyyaml`.

2. **Run the tracker**
   - Execute the script with the managed Python interpreter.
   - The script fetches configured URLs, compares content hashes with saved snapshots, and writes a Markdown report.

3. **Interpret the output**
   - Reports are saved in `policy_tracker_data/reports/`.
   - JSON run logs are saved in `policy_tracker_data/`.
   - Changed pages are flagged; failures are listed separately.

4. **Extend the tracker**
   - Add new countries/pathways to the `DEFAULT_SOURCES` list in the script or to `config/sources.yaml`.
   - Add priority labels (P0/P1/P2) so the user can focus on the most relevant destinations first.
   - Replace simple text hashing with metric extraction (Pydantic models, CSV/JSON outputs) when the project matures.

5. **Publish / CV framing**
   - Create a GitHub repository.
   - Add a GitHub Actions workflow for daily runs.
   - Serve the latest report via GitHub Pages.
   - Add the project to the user's CV and KOS academic website.

## Bundled Resources

- `scripts/tracker_mvp.py`: Self-contained MVP script that fetches 11 pathways across 10 countries, detects changes, and writes a Markdown report.
- `references/policy_sources.md`: Curated list of official policy source URLs and baseline 2026 thresholds.

## Key Technical Details

- Use the managed Python venv: `C:\Users\Mr_Wang\.workbuddy\binaries\python\envs\default\Scripts\python.exe`.
- Quote paths when invoking from Bash on Windows to avoid backslash escaping issues.
- The script stores snapshots under `policy_tracker_data/history/`. Delete a snapshot to force a fresh comparison.
- The script is read-only on source sites; respect robots.txt and keep request frequency to once per day.

## Important Notes

- The tracker produces factual snapshots, not legal advice. Always tell the user to verify with official sources or an immigration lawyer before acting.
- When mentioning Hong Kong, Taiwan, or Macao, use "中国香港 / Hong Kong, China" and "中国台湾 / Taiwan, China" or "中国澳门 / Macao, China".
- Keep the user's main goal in mind: the tracker is a tool, not a substitute for the Germany PhD主线 or NZ Green List job applications.

## Quick Start

```bash
# Install dependencies
"C:\Users\Mr_Wang\.workbuddy\binaries\python\envs\default\Scripts\python.exe" -m pip install requests beautifulsoup4 lxml pyyaml

# Run the tracker
"C:\Users\Mr_Wang\.workbuddy\binaries\python\envs\default\Scripts\python.exe" global_policy_tracker.py
```

Then open `policy_tracker_data/reports/report_YYYY-MM-DD.md` for the latest summary.
