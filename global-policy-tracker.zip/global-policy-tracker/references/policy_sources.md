# 全球技术移民政策追踪器：官方源与 2026 基线数据

> **用途**：作为 `global_policy_tracker.py` 的参考数据与初始种子。正式上线后，应以每次抓取到的官方页面为准。

## P0 优先目的地（与当前主线直接相关）

### 新西兰 · New Zealand

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Green List Tier 1 — Straight to Residence | 中位数工资 | NZD 33.56/hr | https://www.immigration.govt.nz/live/resident-visas-to-live-in-new-zealand/skilled-residence-pathways-in-new-zealand/green-list-pathway-to-residence/ |
| Straight to Residence Visa | 年龄上限、英语要求、雇主资质 | ≤55 岁；雇主需 accredited | https://www.immigration.govt.nz/visas/straight-to-residence-visa/ |
| Accredited Employer List | 雇主是否 accredited | 需查询 | https://www.immigration.govt.nz/employ-migrants/accreditation-and-job-checks/accredited-employers-list |

**绿名单 Tier 1 ICT 岗位（8 个）**：
- Software Engineer / Software Developer (261313)
- Database Administrator (262111)
- Systems Administrator (262113)
- Analyst Programmer (261311)
- Developer Programmer (261312)
- ICT Project Manager (135112)
- ICT Security Specialist (262112)
- CIO (135111)

### 德国 · Germany

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| EU Blue Card 普通 | 年薪门槛 | €50,700/年 | https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card |
| EU Blue Card 短缺/年轻/IT 无学位 | 年薪门槛 | €45,934/年 | https://www.bamf.de/EN/Themen/Statistik/BlaueKarteEU/blauekarteeu-node.html |
| Opportunity Card (Chancenkarte) | 积分标准 | 2026 年 3 月起可用 | https://www.make-it-in-germany.com/en/visa-residence/types/opportunity-card |
| §18d Research / PhD | 无统一薪资门槛 | 岗位制博士按 TVöD/TV-L 合同 | https://www.auswaertiges-amt.de/en/visa-service/visum-uebersicht/scientific-research/1581988 |

### 荷兰 · Netherlands

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Highly Skilled Migrant 30 岁以下 | 月薪门槛 | €4,357/月 | https://ind.nl/en/required-amounts-income-requirements |
| Highly Skilled Migrant 30 岁及以上 | 月薪门槛 | €5,942/月 | https://ind.nl/en/required-amounts-income-requirements |
| Reduced rate / 应届生 | 月薪门槛 | €3,122/月 | https://ind.nl/en/required-amounts-income-requirements |
| EU Blue Card | 月薪门槛 | €5,942/月 | https://ind.nl/en/required-amounts-income-requirements |

## P1 副线目的地

### 瑞典 · Sweden

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Work Permit | 薪资门槛 | ≥90% 中位工资（2026.6.1 起） | https://www.migrationsverket.se/English/Private-individuals/Working-in-Sweden.html |

### 芬兰 · Finland

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Specialist Permit | 薪资门槛 | 需满足足够生活来源 | https://migri.fi/en/information-bank/specialists |

### 爱尔兰 · Ireland

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Critical Skills Employment Permit | 年薪门槛 | €40,904/年 | https://enterprise.gov.ie/en/what-we-do/workplace-and-skills/employment-permits/permit-types/critical-skills-employment-permit/ |

## P2 观察目的地

### 澳大利亚 · Australia

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Skills in Demand (subclass 482) Core Skills | 年薪门槛 | AUD 79,423/年 | https://immi.homeaffairs.gov.au/visas/employing-and-sponsoring-someone/sponsoring-workers/nominating-a-position/salary-requirements |
| Specialist Skills Pathway | 年薪门槛 | AUD 146,576/年 | 同上 |

### 加拿大 · Canada

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Express Entry | CRS 邀请分 | 按轮次变化 | https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry.html |

### 英国 · United Kingdom

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Skilled Worker Visa | 年薪门槛 | £41,700/年 | https://www.gov.uk/skilled-worker-visa |

### 新加坡 · Singapore

| 路径 | 关键指标 | 2026 基线 | 官方源 |
|------|---------|-----------|--------|
| Employment Pass | 月薪门槛 | SGD 5,600/月（非金融） | https://www.mom.gov.sg/passes-and-permits/employment-pass |

---

## 跟踪指标建议

对每个国家/路径，建议抓取并结构化以下指标：

- 薪资门槛（年薪/月薪/时薪）
- 年龄上限
- 英语/语言要求
- 学历/职业清单变化
- 申请费用
- 处理时间
- 永居/入籍年限要求
- 雇主资质要求（accredited / recognized sponsor）

## 免责声明

本文件仅用于项目初始种子数据。所有政策数字请以官方源最新页面为准。本项目不提供法律或移民建议。
