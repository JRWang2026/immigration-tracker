---
name: local-seek-agent
description: 部署并维护王工私人本地 Agent，用于从 QQ Mail IMAP 自动扫描 SEEK NZ 绿名单 Tier1 ICT 岗位，生成 Markdown 报告和 KOS 数据 feed。
---

# Local SEEK Agent Skill

## 何时使用

- 用户想要**自建本地 agent**，替代平台提供的 QQ Mail 连接器；
- 用户想要把 SEEK NZ 岗位扫描、德国博士扫描、政策追踪等任务**跑在自己机器上**；
- 用户想把 agent 输出**接到 KOS 学术网站**展示；
- 用户询问如何设置 Windows 任务计划、QQ Mail 应用专用密码、环境变量等。

## 核心能力

1. **本地 IMAP 邮件扫描**：不依赖平台连接器，直接连 QQ Mail IMAP。
2. **SEEK HTML 解析**：从 SEEK 推送邮件中提取岗位信息。
3. **绿名单 Tier1 ICT 评分**：严格限定绿名单 ICT + 大学研究岗。
4. **报告与数据输出**：Markdown 报告 + JSON 数据 + KOS feed。
5. **Windows 任务计划**：每日自动运行。

## 项目位置

```text
C:\Users\Mr_Wang\WorkBuddy\2026-06-20-14-48-36\local_agent\
```

## 快速开始

### 1. 安装依赖

```powershell
C:\Users\Mr_Wang\.workbuddy\binaries\python\envs\default\Scripts\python.exe -m pip install -r C:\Users\Mr_Wang\WorkBuddy\2026-06-20-14-48-36\local_agent\requirements.txt
```

### 2. 设置环境变量

```powershell
[System.Environment]::SetEnvironmentVariable("QQ_MAIL_USER", "349376374@qq.com", "User")
[System.Environment]::SetEnvironmentVariable("QQ_MAIL_APP_PASSWORD", "你的16位应用专用密码", "User")
```

### 3. 运行

```powershell
cd C:\Users\Mr_Wang\WorkBuddy\2026-06-20-14-48-36\local_agent
C:\Users\Mr_Wang\.workbuddy\binaries\python\envs\default\Scripts\python.exe seek_email_agent.py
```

### 4. 设置每日任务

```powershell
# 以管理员身份运行 PowerShell
.\setup_windows_task.ps1
```

## 架构

```text
local_agent/
├── config.yaml                 # 全局配置（无密码）
├── requirements.txt            # Python 依赖
├── email_client.py             # IMAP 客户端 + 凭据加载
├── seek_parser.py              # SEEK 邮件 HTML 解析
├── green_list_scorer.py        # NZ 绿名单 Tier1 ICT 评分
├── seek_email_agent.py         # SEEK NZ 扫描主程序
├── kos_bridge.py               # KOS 数据桥接
├── scheduler.py                # Python 内置调度（可选）
├── setup_windows_task.ps1      # Windows 任务计划创建脚本
├── kos_page_example.tsx        # KOS Next.js 页面示例
└── README.md
```

## KOS 集成（已完成）

Agent 输出到：

```text
../local_agent_output/kos/seek-nz_latest.json
../local_agent_output/kos/seek-nz_YYYY-MM-DD.json
../local_agent_output/kos/index.json
```

已同步到 KOS 项目：

- 数据文件：`C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos\public\data\seek-nz\latest.json`
- 中文页面：`C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos\app\intelligence\page.tsx`
- 英文页面：`C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos\app\en\intelligence\page.tsx`
- 展示组件：`C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos\components\IntelligenceDashboard.tsx`

同步命令（每次 Agent 运行后执行）：

```powershell
cp C:\Users\Mr_Wang\WorkBuddy\2026-06-20-14-48-36\local_agent_output\kos\seek-nz_latest.json `
   C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos\public\data\seek-nz\latest.json

cd C:\Users\Mr_Wang\WorkBuddy\2026-06-03-14-49-17\kos
npm run build
```

## 安全原则

- 不硬编码密码；
- 使用 QQ Mail **应用专用密码**；
- 凭据通过环境变量或 Windows Credential Manager 注入；
- 所有代码和数据都在本地。

## 扩展方向

- 接入德国博士扫描 `scan_german_phd.py`；
- 接入全球政策追踪 `global_policy_tracker.py`；
- 增加 Web UI（Streamlit / Gradio）；
- 增加变化告警（邮件/Slack）。
